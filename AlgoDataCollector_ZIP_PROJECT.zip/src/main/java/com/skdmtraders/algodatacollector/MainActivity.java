package com.skdmtraders.algodatacollector;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 32);

        TextView title = new TextView(this);
        title.setText("Algo Data Collector");
        title.setTextSize(26);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("NIFTY / SENSEX • Market Data MVP");
        sub.setTextSize(16);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        Spinner index = new Spinner(this);
        index.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"NIFTY 50", "SENSEX"}));
        root.addView(index);

        Spinner timeframe = new Spinner(this);
        timeframe.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1 Minute", "5 Minutes", "30 Minutes", "1 Hour", "1 Day"}));
        root.addView(timeframe);

        Button export = new Button(this);
        export.setText("Prepare CSV Data");
        root.addView(export);

        TextView status = new TextView(this);
        status.setText("Ready. Data collection module will be added next.");
        status.setPadding(0, 30, 0, 0);
        root.addView(status);

        setContentView(root);
    }
}
